"""AedesWatch demo app.

Run with:
    streamlit run app/streamlit_app.py
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.detection.infer import detect
from src.risk_prediction.predict import predict as predict_risk

MODEL_PATH = Path("models/risk_model.joblib")
SAMPLE_INFER_PATH = Path("data/sample/risk_inference_example.csv")

st.set_page_config(page_title="AedesWatch", page_icon="🦟", layout="centered")
st.title("🦟 AedesWatch")
st.caption("Aedes breeding-site detection & dengue/Zika outbreak risk — portfolio demo")

tab1, tab2 = st.tabs(["📷 Inspect a photo", "📊 Regional risk"])

with tab1:
    st.subheader("Upload a field photo")
    st.write(
        "Flags likely breeding sites (standing water containers) and mosquitoes. "
        "Without trained YOLO weights, this uses a seeded mock detector so the "
        "UI/pipeline can be demoed end-to-end — see README for training on real data."
    )
    uploaded = st.file_uploader("Image", type=["jpg", "jpeg", "png"])
    weights_path = st.text_input("Path to trained weights (optional)", value="")

    if uploaded is not None:
        tmp_path = Path("_uploaded_tmp") / uploaded.name
        tmp_path.parent.mkdir(exist_ok=True)
        tmp_path.write_bytes(uploaded.getvalue())

        st.image(uploaded, caption="Uploaded image", use_container_width=True)

        detections = detect(str(tmp_path), weights_path or None)
        if detections:
            st.success(f"{len(detections)} detection(s) found")
            df = pd.DataFrame(
                [{"label": d.label, "confidence": d.confidence} for d in detections]
            )
            st.dataframe(df, use_container_width=True, hide_index=True)
        else:
            st.info("No breeding sites or mosquitoes detected in this image.")

with tab2:
    st.subheader("Regional outbreak risk")
    if not MODEL_PATH.exists():
        st.warning(
            "No trained risk model found at `models/risk_model.joblib`. "
            "Run the Quickstart steps 1–2 in the README to generate data and train it."
        )
    elif not SAMPLE_INFER_PATH.exists():
        st.warning(
            "No inference sample found. Run `python data/generate_synthetic_data.py --out data/sample` first."
        )
    else:
        df = pd.read_csv(SAMPLE_INFER_PATH)
        region = st.selectbox("Region", sorted(df["region"].unique()))
        row = df[df["region"] == region]

        result = predict_risk(row, str(MODEL_PATH))
        score = float(result["predicted_risk_score"].iloc[0])
        band = str(result["risk_band"].iloc[0])

        band_color = {"Low": "🟢", "Moderate": "🟡", "High": "🟠", "Severe": "🔴"}.get(band, "⚪")
        st.metric(f"{region} — current risk", f"{score:.1f} / 100", delta=band)
        st.write(f"{band_color} Risk band: **{band}**")

        with st.expander("Input features used"):
            feature_cols = [
                "breeding_site_density", "rainfall_mm_7d", "rainfall_mm_14d",
                "avg_temp_c", "humidity_pct", "population_density", "prior_cases_4wk",
            ]
            st.dataframe(row[feature_cols], use_container_width=True, hide_index=True)

st.divider()
st.caption(
    "Demo only — synthetic data by default. See README for plugging in real "
    "Mosquito Alert imagery and DGHS/WHO case + Open-Meteo weather data."
)
