import sys
from pathlib import Path

import joblib

sys.path.append(str(Path(__file__).resolve().parents[1]))

from data.generate_synthetic_data import generate
from src.risk_prediction.features import FEATURE_COLUMNS, build_features
from src.risk_prediction.model import build_model
from src.risk_prediction.predict import predict


def test_end_to_end_train_predict(tmp_path):
    # small synthetic dataset, fast to train
    df = generate(n_weeks=20, n_regions=3, seed=1)

    X = build_features(df)
    y = df["risk_score"]
    model = build_model(random_state=1)
    model.fit(X, y)

    model_path = tmp_path / "model.joblib"
    joblib.dump({"model": model, "feature_columns": FEATURE_COLUMNS}, model_path)

    inference_rows = df.drop(columns=["risk_score", "confirmed_cases"]).head(5)
    result = predict(inference_rows, str(model_path))

    assert "predicted_risk_score" in result.columns
    assert "risk_band" in result.columns
    assert len(result) == len(inference_rows)
    assert result["predicted_risk_score"].between(0, 100).all()
