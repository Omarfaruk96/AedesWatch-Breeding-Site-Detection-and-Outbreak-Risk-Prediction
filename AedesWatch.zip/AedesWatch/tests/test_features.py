import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.risk_prediction.features import (
    FEATURE_COLUMNS,
    REQUIRED_RAW_COLUMNS,
    build_features,
)


def _sample_df(n=3):
    return pd.DataFrame(
        {
            "breeding_site_density": [5.0] * n,
            "rainfall_mm_7d": [20.0] * n,
            "rainfall_mm_14d": [35.0] * n,
            "avg_temp_c": [28.0] * n,
            "humidity_pct": [70.0] * n,
            "population_density": [15000.0] * n,
            "prior_cases_4wk": [1.0] * n,
            "season_week": [1, 26, 52],
        }
    )


def test_build_features_returns_expected_columns():
    df = _sample_df()
    out = build_features(df)
    assert list(out.columns) == FEATURE_COLUMNS
    assert len(out) == len(df)


def test_cyclical_week_wraps_correctly():
    df = _sample_df()
    out = build_features(df)
    # week 1 and week 52 should be close in sin/cos space (adjacent on the year cycle)
    week1 = out.iloc[0][["season_week_sin", "season_week_cos"]].to_numpy()
    week52 = out.iloc[2][["season_week_sin", "season_week_cos"]].to_numpy()
    distance = ((week1 - week52) ** 2).sum() ** 0.5
    assert distance < 0.3


def test_missing_column_raises():
    df = _sample_df().drop(columns=["rainfall_mm_7d"])
    with pytest.raises(ValueError, match="Missing required columns"):
        build_features(df)


def test_required_columns_cover_all_non_cyclical_features():
    non_cyclical = [c for c in FEATURE_COLUMNS if c not in ("season_week_sin", "season_week_cos")]
    for col in non_cyclical:
        assert col in REQUIRED_RAW_COLUMNS
