"""Prepare a labeled image dataset for YOLO training.

This repo does NOT ship third-party mosquito/breeding-site images (licensing).
Use this script once you've gathered your own images + annotations, e.g. from:

  - Mosquito Alert (https://www.mosquitoalert.com/en/) exports
  - Your own field photos, labeled with LabelImg (https://github.com/HumanSignal/labelImg)
    or CVAT (https://www.cvat.ai/)

Expected INPUT layout (COCO-style, one annotations.json + flat image folder):

    raw_dataset/
      images/
        img001.jpg
        img002.jpg
        ...
      annotations.json          # COCO format: images, annotations, categories

This script converts that into the YOLO layout `aedeswatch.yaml` expects:

    data/detection_dataset/
      images/train/*.jpg
      images/val/*.jpg
      labels/train/*.txt
      labels/val/*.txt

Usage:
    python src/detection/dataset_prep.py --coco raw_dataset --out data/detection_dataset \
                                          --val-split 0.15
"""
from __future__ import annotations

import argparse
import json
import random
import shutil
from pathlib import Path


def coco_to_yolo_box(bbox: list[float], img_w: int, img_h: int) -> tuple[float, float, float, float]:
    """COCO bbox is [x_min, y_min, width, height] in pixels.
    YOLO wants [x_center, y_center, width, height], all normalized 0-1."""
    x_min, y_min, w, h = bbox
    x_center = (x_min + w / 2) / img_w
    y_center = (y_min + h / 2) / img_h
    return x_center, y_center, w / img_w, h / img_h


def convert(coco_dir: Path, out_dir: Path, val_split: float, seed: int = 42) -> None:
    ann_path = coco_dir / "annotations.json"
    if not ann_path.exists():
        raise FileNotFoundError(
            f"Expected {ann_path}. See this script's docstring for the required input layout."
        )

    with open(ann_path) as f:
        coco = json.load(f)

    images_by_id = {img["id"]: img for img in coco["images"]}
    anns_by_image: dict[int, list[dict]] = {}
    for ann in coco["annotations"]:
        anns_by_image.setdefault(ann["image_id"], []).append(ann)

    # COCO category_id (often 1-indexed, non-contiguous) -> contiguous YOLO class index
    cat_ids = sorted(c["id"] for c in coco["categories"])
    cat_id_to_yolo = {cid: i for i, cid in enumerate(cat_ids)}

    image_ids = list(images_by_id.keys())
    random.Random(seed).shuffle(image_ids)
    n_val = max(1, int(len(image_ids) * val_split))
    val_ids = set(image_ids[:n_val])

    for split in ("train", "val"):
        (out_dir / "images" / split).mkdir(parents=True, exist_ok=True)
        (out_dir / "labels" / split).mkdir(parents=True, exist_ok=True)

    n_written = 0
    for img_id, img in images_by_id.items():
        split = "val" if img_id in val_ids else "train"
        src_img = coco_dir / "images" / img["file_name"]
        if not src_img.exists():
            print(f"  [skip] missing image file: {src_img}")
            continue

        dst_img = out_dir / "images" / split / img["file_name"]
        shutil.copy2(src_img, dst_img)

        label_lines = []
        for ann in anns_by_image.get(img_id, []):
            yolo_cls = cat_id_to_yolo[ann["category_id"]]
            xc, yc, w, h = coco_to_yolo_box(ann["bbox"], img["width"], img["height"])
            label_lines.append(f"{yolo_cls} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}")

        label_path = out_dir / "labels" / split / (Path(img["file_name"]).stem + ".txt")
        label_path.write_text("\n".join(label_lines))
        n_written += 1

    print(f"Converted {n_written} images ({len(val_ids)} val / {n_written - len(val_ids)} train)")
    print(f"Class mapping: {[(c['name'], cat_id_to_yolo[c['id']]) for c in coco['categories']]}")
    print(f"Done. Point aedeswatch.yaml's `path` at: {out_dir.resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--coco", type=str, required=True, help="Folder with images/ and annotations.json")
    parser.add_argument("--out", type=str, default="data/detection_dataset")
    parser.add_argument("--val-split", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    convert(Path(args.coco), Path(args.out), args.val_split, args.seed)


if __name__ == "__main__":
    main()
