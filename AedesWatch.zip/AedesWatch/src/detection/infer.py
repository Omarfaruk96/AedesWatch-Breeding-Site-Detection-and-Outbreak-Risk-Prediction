"""Run breeding-site/mosquito detection on an image.

If no trained weights are available, falls back to a clearly-labeled mock
detector so the rest of the pipeline (and the demo app) can still be
exercised end-to-end without a GPU or a trained model. This is intentional —
see README Quickstart step 4.

Usage:
    python src/detection/infer.py --image path/to/photo.jpg --weights models/best.pt
    python src/detection/infer.py --image path/to/photo.jpg   # uses mock detector
"""
from __future__ import annotations

import argparse
import random
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Detection:
    label: str
    confidence: float
    box_xyxy: tuple[float, float, float, float]  # pixel coords


CLASS_NAMES = ["standing_water_container", "aedes_aegypti", "aedes_albopictus", "other_mosquito"]


def _mock_detect(image_path: Path) -> list[Detection]:
    """Deterministic pseudo-random detections, seeded on the filename, so the
    demo app behaves consistently for the same image without needing real
    trained weights. Clearly NOT a real model — replace by training on real
    data (see README > Detection pipeline > Data sources)."""
    rng = random.Random(str(image_path))
    n = rng.randint(1, 3)
    detections = []
    for _ in range(n):
        label = rng.choice(CLASS_NAMES)
        conf = round(rng.uniform(0.55, 0.95), 2)
        x1, y1 = rng.uniform(0, 0.6), rng.uniform(0, 0.6)
        x2, y2 = x1 + rng.uniform(0.1, 0.35), y1 + rng.uniform(0.1, 0.35)
        detections.append(Detection(label, conf, (x1, y1, x2, y2)))
    return detections


def detect(image_path: str, weights_path: str | None = None, conf_threshold: float = 0.4) -> list[Detection]:
    img_path = Path(image_path)
    if not img_path.exists():
        raise FileNotFoundError(image_path)

    if weights_path and Path(weights_path).exists():
        try:
            from ultralytics import YOLO
        except ImportError as exc:
            raise SystemExit("ultralytics is not installed. Run: pip install ultralytics") from exc

        model = YOLO(weights_path)
        results = model.predict(str(img_path), conf=conf_threshold, verbose=False)
        detections = []
        for r in results:
            for box in r.boxes:
                cls_idx = int(box.cls.item())
                label = r.names.get(cls_idx, str(cls_idx))
                conf = float(box.conf.item())
                xyxy = tuple(box.xyxy[0].tolist())
                detections.append(Detection(label, conf, xyxy))
        return detections

    print("[AedesWatch] No weights found — using mock detector for demonstration purposes.")
    return _mock_detect(img_path)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", type=str, required=True)
    parser.add_argument("--weights", type=str, default=None, help="Path to trained .pt weights")
    parser.add_argument("--conf", type=float, default=0.4)
    args = parser.parse_args()

    detections = detect(args.image, args.weights, args.conf)
    if not detections:
        print("No breeding sites or mosquitoes detected.")
        return

    for d in detections:
        print(f"{d.label:28s} conf={d.confidence:.2f}  box={tuple(round(v, 3) for v in d.box_xyxy)}")


if __name__ == "__main__":
    main()
