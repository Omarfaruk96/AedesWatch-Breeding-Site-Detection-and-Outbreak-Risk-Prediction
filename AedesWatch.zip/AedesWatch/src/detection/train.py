"""Train the breeding-site / mosquito detection model (YOLOv8).

Requires the optional `ultralytics` dependency:
    pip install ultralytics

Usage:
    python src/detection/train.py --data src/detection/config/aedeswatch.yaml \
                                   --epochs 50 --model yolov8n.pt
"""
from __future__ import annotations

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=str, required=True, help="Path to YOLO data.yaml")
    parser.add_argument("--model", type=str, default="yolov8n.pt", help="Base weights to fine-tune from")
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--project", type=str, default="runs/detect")
    parser.add_argument("--name", type=str, default="aedeswatch")
    args = parser.parse_args()

    try:
        from ultralytics import YOLO
    except ImportError as exc:
        raise SystemExit(
            "ultralytics is not installed. Run: pip install ultralytics\n"
            "(It's kept optional since the risk-prediction half of this repo doesn't need it.)"
        ) from exc

    model = YOLO(args.model)
    model.train(
        data=args.data,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        project=args.project,
        name=args.name,
    )
    print(f"Training complete. Weights saved under {args.project}/{args.name}/weights/best.pt")


if __name__ == "__main__":
    main()
