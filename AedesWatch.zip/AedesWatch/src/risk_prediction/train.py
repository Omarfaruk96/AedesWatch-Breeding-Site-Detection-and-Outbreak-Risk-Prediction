"""Train the outbreak risk prediction model.

Usage:
    python src/risk_prediction/train.py --data data/sample/risk_training_data.csv \
                                         --out models/risk_model.joblib
"""
from __future__ import annotations

import argparse

# allow running as `python src/risk_prediction/train.py` without package install
import sys
from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.risk_prediction.features import FEATURE_COLUMNS, TARGET_COLUMN, build_features
from src.risk_prediction.model import build_model


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=str, required=True, help="Path to training CSV")
    parser.add_argument("--out", type=str, default="models/risk_model.joblib")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    df = pd.read_csv(args.data)
    if TARGET_COLUMN not in df.columns:
        raise ValueError(f"Training data must include target column '{TARGET_COLUMN}'")

    X = build_features(df)
    y = df[TARGET_COLUMN]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_size, random_state=args.seed
    )

    model = build_model(random_state=args.seed)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)
    print(f"Validation MAE:  {mae:.2f} risk points")
    print(f"Validation R^2:  {r2:.3f}")

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": model, "feature_columns": FEATURE_COLUMNS}, out_path)
    print(f"Saved model to {out_path}")


if __name__ == "__main__":
    main()
