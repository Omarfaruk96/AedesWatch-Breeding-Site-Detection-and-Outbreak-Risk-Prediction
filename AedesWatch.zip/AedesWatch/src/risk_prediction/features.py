"""Feature engineering shared by training and inference.

Kept separate from train.py/predict.py so it's independently unit-testable
and so training/inference can never silently drift apart.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

FEATURE_COLUMNS = [
    "breeding_site_density",
    "rainfall_mm_7d",
    "rainfall_mm_14d",
    "avg_temp_c",
    "humidity_pct",
    "population_density",
    "prior_cases_4wk",
    "season_week_sin",
    "season_week_cos",
]

TARGET_COLUMN = "risk_score"

REQUIRED_RAW_COLUMNS = [
    "breeding_site_density",
    "rainfall_mm_7d",
    "rainfall_mm_14d",
    "avg_temp_c",
    "humidity_pct",
    "population_density",
    "prior_cases_4wk",
    "season_week",
]


def add_cyclical_week(df: pd.DataFrame) -> pd.DataFrame:
    """Encode week-of-year (1-52) as sin/cos so the model sees it as cyclical
    instead of a jump from 52 back to 1."""
    out = df.copy()
    radians = 2 * np.pi * out["season_week"].astype(float) / 52.0
    out["season_week_sin"] = np.sin(radians)
    out["season_week_cos"] = np.cos(radians)
    return out


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Validate required raw columns exist, then return the model-ready
    feature matrix (FEATURE_COLUMNS only, in order)."""
    missing = [c for c in REQUIRED_RAW_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns for feature engineering: {missing}")

    enriched = add_cyclical_week(df)
    return enriched[FEATURE_COLUMNS]
