"""Predict outbreak risk scores for new region-week rows.

Usage:
    python src/risk_prediction/predict.py --model models/risk_model.joblib \
                                           --input data/sample/risk_inference_example.csv
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import joblib
import pandas as pd

sys.path.append(str(Path(__file__).resolve().parents[2]))

from src.risk_prediction.features import build_features


def load_model(model_path: str):
    bundle = joblib.load(model_path)
    return bundle["model"], bundle["feature_columns"]


def predict(df: pd.DataFrame, model_path: str) -> pd.DataFrame:
    model, feature_columns = load_model(model_path)
    X = build_features(df)[feature_columns]
    scores = model.predict(X)

    result = df.copy()
    result["predicted_risk_score"] = scores.round(1)
    result["risk_band"] = pd.cut(
        result["predicted_risk_score"],
        bins=[-1, 25, 50, 75, 101],
        labels=["Low", "Moderate", "High", "Severe"],
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--input", type=str, required=True)
    parser.add_argument("--out", type=str, default=None, help="Optional path to save predictions CSV")
    args = parser.parse_args()

    df = pd.read_csv(args.input)
    result = predict(df, args.model)

    cols_to_show = ["region", "week", "predicted_risk_score", "risk_band"]
    cols_to_show = [c for c in cols_to_show if c in result.columns]
    print(result[cols_to_show].to_string(index=False))

    if args.out:
        result.to_csv(args.out, index=False)
        print(f"\nSaved full predictions to {args.out}")


if __name__ == "__main__":
    main()
