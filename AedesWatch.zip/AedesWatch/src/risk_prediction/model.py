"""Thin wrapper around the sklearn regressor so train/predict share one
definition of "what the model is" and it's trivial to swap in XGBoost or
LightGBM later without touching train.py/predict.py call sites."""
from __future__ import annotations

from sklearn.ensemble import HistGradientBoostingRegressor


def build_model(random_state: int = 42) -> HistGradientBoostingRegressor:
    return HistGradientBoostingRegressor(
        max_iter=300,
        max_depth=6,
        learning_rate=0.05,
        l2_regularization=0.1,
        random_state=random_state,
    )
