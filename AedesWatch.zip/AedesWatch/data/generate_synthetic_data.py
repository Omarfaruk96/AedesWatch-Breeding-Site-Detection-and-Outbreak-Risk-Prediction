"""
Generate synthetic region-week data for the outbreak risk prediction model.

This lets the whole pipeline (train -> predict -> demo app) run end-to-end
with zero external downloads. Replace with real DGHS/WHO case data and
Open-Meteo weather pulls for a research-grade model (see README > Data
Sources).

Usage:
    python data/generate_synthetic_data.py --out data/sample --weeks 104 --regions 12
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

REGION_NAMES = [
    "Mirpur", "Mohammadpur", "Dhanmondi", "Uttara", "Gulshan", "Badda",
    "Jatrabari", "Khilgaon", "Rampura", "Tejgaon", "Bashundhara", "Lalbagh",
]


def _seasonal_rainfall(week: np.ndarray, base: float, amplitude: float, rng: np.random.Generator) -> np.ndarray:
    """Monsoon-shaped seasonal curve peaking mid-year (weeks ~22-35)."""
    phase = 2 * np.pi * (week - 26) / 52
    seasonal = base + amplitude * np.clip(np.cos(phase), 0, None) ** 1.5
    noise = rng.normal(0, amplitude * 0.15, size=week.shape)
    return np.clip(seasonal + noise, 0, None)


def generate(n_weeks: int, n_regions: int, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    regions = REGION_NAMES[:n_regions] if n_regions <= len(REGION_NAMES) else [
        f"Region_{i}" for i in range(n_regions)
    ]

    rows = []
    for region in regions:
        pop_density = rng.uniform(8_000, 45_000)  # people per sq km, rough Dhaka-ish range
        base_rainfall = rng.uniform(15, 35)
        rain_amp = rng.uniform(60, 140)

        prior_cases = rng.uniform(0, 5)
        for week in range(1, n_weeks + 1):
            season_week = week % 52 or 52
            rainfall_7d = _seasonal_rainfall(np.array([season_week]), base_rainfall, rain_amp, rng)[0]
            rainfall_14d = rainfall_7d * rng.uniform(1.6, 2.1)
            temp = 24 + 6 * np.clip(np.cos(2 * np.pi * (season_week - 22) / 52), -1, 1) + rng.normal(0, 1.2)
            humidity = np.clip(55 + 0.25 * rainfall_7d + rng.normal(0, 4), 30, 98)

            # breeding site density rises with rainfall (standing water) & lags a bit
            breeding_density = np.clip(
                0.15 * rainfall_7d + 0.05 * rainfall_14d + rng.normal(5, 3), 0, None
            )

            # synthetic "true" outbreak risk score, then derive noisy case counts from it
            risk_latent = (
                0.35 * breeding_density
                + 0.25 * rainfall_7d
                + 0.10 * (temp - 27) ** 0 * temp  # mild temp effect, non-linear-ish
                + 0.15 * (humidity - 60)
                + 0.20 * prior_cases
                + 0.00002 * pop_density
            )
            risk_score = np.clip(10 + risk_latent + rng.normal(0, 5), 0, 100)
            cases_this_week = max(0, rng.poisson(lam=max(risk_score / 12, 0.1)))

            rows.append(
                {
                    "region": region,
                    "week": week,
                    "season_week": season_week,
                    "population_density": round(pop_density, 1),
                    "breeding_site_density": round(breeding_density, 2),
                    "rainfall_mm_7d": round(rainfall_7d, 1),
                    "rainfall_mm_14d": round(rainfall_14d, 1),
                    "avg_temp_c": round(temp, 1),
                    "humidity_pct": round(humidity, 1),
                    "prior_cases_4wk": round(prior_cases, 2),
                    "risk_score": round(risk_score, 1),
                    "confirmed_cases": cases_this_week,
                }
            )
            # rolling update of prior_cases_4wk (simple EMA)
            prior_cases = 0.6 * prior_cases + 0.4 * cases_this_week

    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=str, default="data/sample", help="Output directory")
    parser.add_argument("--weeks", type=int, default=104, help="Weeks of history per region")
    parser.add_argument("--regions", type=int, default=12, help="Number of regions to simulate")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = generate(args.weeks, args.regions, args.seed)

    train_path = out_dir / "risk_training_data.csv"
    df.to_csv(train_path, index=False)
    print(f"Wrote {len(df):,} rows to {train_path}")

    # also write a small inference-ready example (latest week per region, no target columns)
    latest = df.sort_values("week").groupby("region").tail(1).drop(columns=["risk_score", "confirmed_cases"])
    infer_path = out_dir / "risk_inference_example.csv"
    latest.to_csv(infer_path, index=False)
    print(f"Wrote {len(latest):,} rows to {infer_path}")


if __name__ == "__main__":
    main()
